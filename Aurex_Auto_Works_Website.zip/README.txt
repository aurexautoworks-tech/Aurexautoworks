AUREX AUTO WORKS WEBSITE

Files:
- index.html — complete website
- logo.jpg — supplied Aurex Auto Works logo

To publish:
1. Upload both files to a web host.
2. Make sure index.html is in the public/root folder.
3. Open your domain.

The site is responsive and includes phone and WhatsApp buttons.
